# stochICE
Python code using HECRAS controller and RIVICE to stocastically model river ice jams
