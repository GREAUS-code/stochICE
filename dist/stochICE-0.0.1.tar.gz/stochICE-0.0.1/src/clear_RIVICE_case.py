# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 14:57:02 2024

@author: dugj2403
"""

import os

path=os.getcwd()

os.remove(path +'\\' + 'CD1TEST.txt')
os.remove(path +'\\' + 'CD1TEST_intp.txt')
os.remove(path +'\\' + 'CD1TEST_no_intp.txt')

os.remove(path +'\\' + 'DOUT1.TXT')
os.remove(path +'\\' + 'DOUT2.TXT')
# os.remove(path +'\\' + 'DOUT7.TXT')

os.remove(path +'\\' + 'INPT10.TXT')
os.remove(path +'\\' + 'INPT11.TXT')
os.remove(path +'\\' + 'INPT101.TXT')
os.remove(path +'\\' + 'INPT111.TXT')


os.remove(path +'\\' + 'psplot.ps')
os.remove(path +'\\' + 'TAPE5.txt')
os.remove(path +'\\' + 'TESTCD2.txt')